import com.company.Order;
import com.sun.deploy.util.StringUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

/*
@author Kofi Nyantekyi-Owusu
 */
public class ICPChallenge1 {

    //names/addresses of storage files
    static final String fileName="essentials_stock.txt";
    static final String backupName="backup_essentials_stock.txt";

    public static void main(String[] args) {
        genUI();
    }

    public static void genUI(){

        System.out.println("Welcome to the Essentials inventory program.\n");
        System.out.println("Enter 1 to add a new item.");
        System.out.println("Enter 2 to read contents of inventory.");
        System.out.println("Enter 3 to close program.");

        Scanner input=new Scanner(System.in);
        String ans=input.next();
        while(ans.matches("(123)")){
            System.out.println("Invalid input. Please, enter a number from 1 to 3");
            ans=input.next();
        }

        while(!ans.equals("3")){
            if(ans.equals("1")){
                getNewOrder();
            }
            else{
                readOrders();
            }
            System.out.println();
            System.out.println("Enter 1 to add a new item.");
            System.out.println("Enter 2 to read contents of inventory.");
            System.out.println("Enter 3 to close program.");
            ans=input.next();
            while(ans.matches("(123)")){
                System.out.println("Invalid input. Please, enter a number from 1 to 3");
                ans=input.next();
            }
        }


    }

    public static void getNewOrder(){
        Scanner newOrder=new Scanner(System.in);

        //Gets item name
        System.out.println("Enter item name: \t");
        String input=newOrder.nextLine();
        while(input.isEmpty()){
            System.out.print("Invalid input. Please enter an alphanumeric string: \t");
            input=newOrder.nextLine();
        }
        String name=input;

        //Gets item price; regex acts as validation
        System.out.print("Enter price in GHC: \t");
        input=newOrder.nextLine();
        while(!input.matches("[0-9]+((.)[0-9]+)?")){
            System.out.print("Invalid input. Please enter a numeric string (e.g.,5.4): \t");
            input=newOrder.nextLine();
        }
        double price=Double.parseDouble(input);

        //Gets number of items orders; regex acts as validation
        System.out.println("Enter number of items, as integer: \t");
        input=newOrder.nextLine();
        while(!input.matches("[0-9]+")){
            System.out.print("Invalid input. Please enter a positive integer: \t");
            input=newOrder.nextLine();
        }
        int quantity=Integer.parseInt(input);


        //Generate Order object and write to file
        Order order= genOrder(name,price, quantity);
        try {
            addOrder(order);
        } catch (IOException e) {
            e.printStackTrace();
        }
        saveBackup();

    }

    public static Order genOrder(String name,double price, int quantity){
        /**
         * @param name
         * Name of the order; of type String
         * @param price
         * The price of the order; of type double
         *@param quantity
         * The number of orders; of type int
         */
        Order order= new Order(name,price, quantity);
        return order;
    }

    public static void addOrder(Order order) throws IOException {
        /**
         * @param order
         * An Order object; contains details of the order (name, price, quantity).
         */
        try {
            //Prints new order to essentials_stock.txt
            PrintWriter orders=new PrintWriter(new FileOutputStream(fileName,true));
            orders.println(order.fileFormat());
            orders.close();
        } catch (FileNotFoundException e) {
            //Creates essentials_stock.txt if not existing, and redoes try block
            File file=new File(fileName);
            if(file.createNewFile()){
                addOrder(order);
            }

        }
    }

    public static void readOrders(){
        System.out.println("List of items in Essentials inventory: ");

        try {
            File file=new File(fileName);
            Scanner orders=new Scanner(file);
            while (orders.hasNext()){
                String[] info=orders.nextLine().split("\t");
                try {
                    Order order=new Order(info[0],Double.parseDouble(info[1]),Integer.parseInt(info[2]));
                    System.out.println(order);
                }
                catch (Exception e){
                    System.out.println("Invalid row");
               }


            }

        } catch (Exception e) {
            File file=new File(fileName);
            e.printStackTrace();
            readOrders();
        }
    }



    public static void saveBackup(){

        File ofile=new File(fileName);
        File dfile=new File(backupName);
        try {
            Files.copy(ofile.toPath(),dfile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
